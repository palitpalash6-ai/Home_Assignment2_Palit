"""
Question 5, Task 2: Implement a Residual Block and ResNet
CS5720 - Home Assignment 2
 
Defines a residual block with a skip connection and uses it to build
a simple ResNet-like model.
"""
 
import tensorflow as tf
from tensorflow.keras import layers, models
 
def residual_block(input_tensor, filters):
    """
    A basic residual block:
    - Two Conv2D layers (each with `filters` filters, 3x3 kernel, ReLU)
    - A skip connection that adds the original input to the output
      before the final activation.
    """
    x = layers.Conv2D(filters, kernel_size=(3, 3), padding="same", activation="relu")(input_tensor)
    x = layers.Conv2D(filters, kernel_size=(3, 3), padding="same")(x)
 
    # Skip connection: add the original input tensor to the block's output
    x = layers.Add()([x, input_tensor])
    x = layers.Activation("relu")(x)
    return x
 
 
def build_resnet(input_shape=(224, 224, 3), num_classes=10):
    inputs = layers.Input(shape=input_shape)
 
    # Initial Conv2D layer
    x = layers.Conv2D(64, kernel_size=(7, 7), strides=2, padding="same", activation="relu")(inputs)
 
    # Two residual blocks (each keeps the same number of channels: 64)
    x = residual_block(x, 64)
    x = residual_block(x, 64)
 
    # Final layers
    x = layers.Flatten()(x)
    x = layers.Dense(128, activation="relu")(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
 
    model = models.Model(inputs=inputs, outputs=outputs, name="simple_resnet")
    return model
 
resnet = build_resnet()
resnet.summary()
